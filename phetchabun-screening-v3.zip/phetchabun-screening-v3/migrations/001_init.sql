create table if not exists participants (
 participant_id uuid primary key default gen_random_uuid(),
 national_id_ciphertext text not null,
 national_id_lookup_hmac char(64) not null unique,
 full_name varchar(160) not null,
 date_of_birth date, sex varchar(30), phone varchar(30),
 district varchar(120) not null, subdistrict varchar(120) not null,
 village varchar(120), health_unit varchar(180) not null,
 created_at timestamptz not null default now()
);
create table if not exists questionnaires (
 questionnaire_id uuid primary key default gen_random_uuid(),
 participant_id uuid not null references participants(participant_id) on delete cascade,
 answers jsonb not null default '{}'::jsonb,
 submitted_at timestamptz not null default now()
);
create table if not exists staff_users (
 staff_user_id uuid primary key default gen_random_uuid(),
 username varchar(80) not null unique, password_hash text not null,
 role varchar(20) not null check(role in ('admin','lab','reviewer')),
 active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists samples (
 sample_id uuid primary key default gen_random_uuid(),
 sample_code varchar(60) not null unique,
 participant_id uuid not null references participants(participant_id),
 received_at date, collection_status varchar(30) not null default 'received',
 created_by uuid references staff_users(staff_user_id), created_at timestamptz not null default now()
);
create table if not exists lab_results (
 result_id uuid primary key default gen_random_uuid(),
 sample_id uuid not null unique references samples(sample_id),
 test_date date not null, method varchar(120) not null,
 result_status varchar(30) not null check(result_status in ('negative','positive','inconclusive','rejected')),
 parasite_name text, findings text, recommendations text,
 review_status varchar(20) not null default 'draft' check(review_status in ('draft','published','revoked')),
 entered_by uuid references staff_users(staff_user_id),
 reviewed_by uuid references staff_users(staff_user_id),
 published_at timestamptz, created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists audit_logs (
 audit_id bigserial primary key,
 staff_user_id uuid references staff_users(staff_user_id),
 event_type varchar(80) not null,
 participant_id uuid references participants(participant_id),
 sample_id uuid references samples(sample_id),
 result_id uuid references lab_results(result_id),
 subject_lookup_hmac char(64), source_ip_hash char(64),
 outcome varchar(40), occurred_at timestamptz not null default now()
);
create index if not exists idx_participants_name on participants using gin(to_tsvector('simple',full_name));
create index if not exists idx_questionnaires_participant on questionnaires(participant_id);
create index if not exists idx_samples_participant on samples(participant_id);
create index if not exists idx_lab_results_review on lab_results(review_status,created_at);
create index if not exists idx_audit_logs_occurred on audit_logs(occurred_at desc);
