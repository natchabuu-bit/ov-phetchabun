require('dotenv').config();
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '30kb' }));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.DB_POOL_MAX || 20),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: true } : undefined
});

function requireSecret(name, bytes = 32) {
  const value = process.env[name] || '';
  if (!/^[0-9a-f]+$/i.test(value) || value.length !== bytes * 2) {
    throw new Error(`${name} must be a ${bytes}-byte hexadecimal secret`);
  }
  return Buffer.from(value, 'hex');
}
const encryptionKey = requireSecret('NATIONAL_ID_ENCRYPTION_KEY');
const hmacKey = requireSecret('NATIONAL_ID_HMAC_KEY');
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error('SESSION_SECRET must be at least 32 characters');
}

app.use(session({
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  name: 'pzb.sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: { httpOnly: true, secure: isProd, sameSite: 'strict', maxAge: 8 * 60 * 60 * 1000 }
}));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-8', legacyHeaders: false });
const registrationLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 6000, standardHeaders: 'draft-8', legacyHeaders: false });
// A high IP threshold avoids blocking a shared clinic Wi-Fi/NAT during a campaign.
const resultIpLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 1500, standardHeaders: 'draft-8', legacyHeaders: false });
const idAttempts = new Map();

function isValidThaiId(id) {
  if (!/^\d{13}$/.test(id)) return false;
  let sum = 0;
  for (let i = 0; i < 12; i++) sum += Number(id[i]) * (13 - i);
  return ((11 - (sum % 11)) % 10) === Number(id[12]);
}
function lookupHmac(id) {
  return crypto.createHmac('sha256', hmacKey).update(id).digest('hex');
}
function encryptId(id) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey, iv);
  const ciphertext = Buffer.concat([cipher.update(id, 'utf8'), cipher.final()]);
  return [iv.toString('hex'), cipher.getAuthTag().toString('hex'), ciphertext.toString('hex')].join(':');
}
function decryptId(value) {
  const [ivHex, tagHex, dataHex] = value.split(':');
  const decipher = crypto.createDecipheriv('aes-256-gcm', encryptionKey, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  return Buffer.concat([decipher.update(Buffer.from(dataHex, 'hex')), decipher.final()]).toString('utf8');
}
function maskId(id) { return id.slice(0, 1) + '********' + id.slice(-4); }
function ipHash(ip) {
  return crypto.createHmac('sha256', hmacKey).update(String(ip || '')).digest('hex');
}
function safeText(value, max = 500) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}
async function audit({ userId = null, event, participantId = null, sampleId = null, resultId = null, idHmac = null, req, outcome = 'success' }) {
  await pool.query(
    `insert into audit_logs(staff_user_id,event_type,participant_id,sample_id,result_id,subject_lookup_hmac,source_ip_hash,outcome)
     values($1,$2,$3,$4,$5,$6,$7,$8)`,
    [userId, event, participantId, sampleId, resultId, idHmac, ipHash(req?.ip), outcome]
  );
}
function requireAuth(req, res, next) {
  if (!req.session?.staff?.id) return res.status(401).json({ message: 'กรุณาเข้าสู่ระบบเจ้าหน้าที่' });
  next();
}
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.session?.staff?.id) return res.status(401).json({ message: 'กรุณาเข้าสู่ระบบเจ้าหน้าที่' });
    if (!roles.includes(req.session.staff.role)) return res.status(403).json({ message: 'บัญชีนี้ไม่มีสิทธิ์ดำเนินการ' });
    next();
  };
}
function requireCsrf(req, res, next) {
  const sent = req.get('X-CSRF-Token');
  if (!sent || !req.session.csrfToken || sent !== req.session.csrfToken) {
    return res.status(403).json({ message: 'คำขอไม่ผ่านการตรวจสอบความปลอดภัย กรุณาโหลดหน้าใหม่' });
  }
  next();
}
function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

async function migrateAndSeed() {
  const sql = fs.readFileSync(path.join(__dirname, 'migrations', '001_init.sql'), 'utf8');
  await pool.query(sql);
  const username = safeText(process.env.ADMIN_USERNAME, 80);
  const password = process.env.ADMIN_PASSWORD || '';
  if (username && password) {
    if (password.length < 14) throw new Error('ADMIN_PASSWORD must be at least 14 characters');
    const exists = await pool.query('select staff_user_id from staff_users where username=$1', [username]);
    if (!exists.rowCount) {
      const hash = await bcrypt.hash(password, 12);
      await pool.query('insert into staff_users(username,password_hash,role) values($1,$2,$3)', [username, hash, 'admin']);
      console.log(`Initial admin account created: ${username}`);
    }
  } else {
    console.warn('ADMIN_USERNAME / ADMIN_PASSWORD not set. No initial admin user was created.');
  }
}

app.get('/healthz', asyncRoute(async (_req, res) => {
  await pool.query('select 1');
  res.json({ ok: true });
}));

// Public registration: the national ID is encrypted at rest and indexed by keyed HMAC.
app.post('/api/public/register', registrationLimiter, asyncRoute(async (req, res) => {
  const b = req.body || {};
  const nationalId = String(b.nationalId || '').replace(/\D/g, '');
  if (!isValidThaiId(nationalId)) return res.status(400).json({ message: 'กรุณาตรวจสอบเลขบัตรประชาชน 13 หลัก' });
  const fullName = safeText(b.fullname, 160);
  const district = safeText(b.district, 120);
  const subdistrict = safeText(b.subdistrict, 120);
  const healthUnit = safeText(b.healthUnit, 180);
  if (!fullName || !district || !subdistrict || !healthUnit || b.acknowledgedPrivacy !== true) {
    return res.status(400).json({ message: 'กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วนและรับทราบประกาศความเป็นส่วนตัว' });
  }
  const answers = {};
  for (const key of ['raw_fish','raw_meat','handwash','footwear','toilet','deworm','soil_water']) {
    answers[key] = safeText(b[key], 100);
  }
  if (Object.values(answers).some(v => !v)) return res.status(400).json({ message: 'กรุณาตอบแบบสอบถามให้ครบทุกข้อ' });
  const hmac = lookupHmac(nationalId);
  const client = await pool.connect();
  let participantId;
  try {
    await client.query('begin');
    const p = await client.query(
      `insert into participants(national_id_ciphertext,national_id_lookup_hmac,full_name,date_of_birth,sex,phone,district,subdistrict,village,health_unit)
       values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) returning participant_id`,
      [encryptId(nationalId), hmac, fullName, b.dob || null, safeText(b.sex,30) || null, safeText(b.phone,30) || null, district, subdistrict, safeText(b.village,120) || null, healthUnit]
    );
    participantId = p.rows[0].participant_id;
    await client.query('insert into questionnaires(participant_id,answers) values($1,$2::jsonb)', [participantId, JSON.stringify(answers)]);
    await client.query('commit');
  } catch (err) {
    await client.query('rollback');
    if (err.code === '23505') return res.status(409).json({ message: 'ไม่สามารถลงทะเบียนได้ กรุณาติดต่อหน่วยบริการเพื่อตรวจสอบข้อมูล' });
    throw err;
  } finally {
    client.release();
  }
  await audit({ event: 'public_registration', participantId, idHmac: hmac, req });
  res.status(201).json({ registered: true, message: 'ลงทะเบียนเรียบร้อยแล้ว' });
}));

// ID-only result lookup as requested by the project owner.
// This is not identity authentication: anyone who knows the ID may request the result.
app.post('/api/public/result', resultIpLimiter, asyncRoute(async (req, res) => {
  const nationalId = String(req.body?.nationalId || '').replace(/\D/g, '');
  if (!isValidThaiId(nationalId)) return res.status(400).json({ found: false, message: 'ไม่พบผลตรวจที่พร้อมเผยแพร่' });
  const hmac = lookupHmac(nationalId);
  const now = Date.now();
  const entry = idAttempts.get(hmac) || { count: 0, resetAt: now + 15 * 60 * 1000 };
  if (entry.resetAt <= now) { entry.count = 0; entry.resetAt = now + 15 * 60 * 1000; }
  entry.count += 1;
  idAttempts.set(hmac, entry);
  if (entry.count > 10) {
    await audit({ event: 'public_result_lookup', idHmac: hmac, req, outcome: 'rate_limited' });
    return res.status(429).json({ found: false, message: 'มีการค้นหาบ่อยเกินไป กรุณาลองใหม่ภายหลัง' });
  }
  if (idAttempts.size > 50000) {
    for (const [key, value] of idAttempts) if (value.resetAt <= now) idAttempts.delete(key);
  }
  const q = await pool.query(
    `select lr.test_date,lr.method,lr.result_status,lr.parasite_name,lr.findings,lr.recommendations
       from participants p join samples s on s.participant_id=p.participant_id
       join lab_results lr on lr.sample_id=s.sample_id
      where p.national_id_lookup_hmac=$1 and lr.review_status='published' and lr.published_at is not null
      order by lr.published_at desc limit 1`, [hmac]
  );
  await audit({ event: 'public_result_lookup', idHmac: hmac, req, outcome: q.rowCount ? 'found' : 'not_found_or_unpublished' });
  if (!q.rowCount) return res.status(200).json({ found: false });
  const r = q.rows[0];
  const labels = { negative: 'ไม่พบพยาธิ', positive: 'พบพยาธิ', inconclusive: 'แปลผลไม่ได้ / ควรตรวจซ้ำ', rejected: 'ตัวอย่างไม่เหมาะสม' };
  res.json({ found: true, testDate: r.test_date, method: r.method, result: labels[r.result_status] || 'มีผลตรวจ', parasite: r.parasite_name || r.findings || '-', advice: r.recommendations || 'กรุณาติดต่อหน่วยบริการเพื่อรับคำแนะนำ' });
}));

app.post('/api/admin/login', loginLimiter, asyncRoute(async (req, res) => {
  const username = safeText(req.body?.username, 80);
  const password = String(req.body?.password || '');
  const q = await pool.query('select staff_user_id,username,password_hash,role,active from staff_users where username=$1', [username]);
  const user = q.rows[0];
  const valid = user && user.active && await bcrypt.compare(password, user.password_hash);
  if (!valid) return res.status(401).json({ message: 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง' });
  await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
  req.session.staff = { id: user.staff_user_id, username: user.username, role: user.role };
  req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  await new Promise((resolve, reject) => req.session.save(err => err ? reject(err) : resolve()));
  await audit({ userId: user.staff_user_id, event: 'staff_login', req });
  res.json({ ok: true });
}));

app.get('/api/admin/me', requireAuth, (req, res) => {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  const roleLabels = { admin: 'ผู้ดูแลระบบ', lab: 'เจ้าหน้าที่ห้องปฏิบัติการ', reviewer: 'ผู้รับรองผล' };
  res.json({ user: { username: req.session.staff.username, role: req.session.staff.role, roleLabel: roleLabels[req.session.staff.role] }, csrfToken: req.session.csrfToken });
});

app.post('/api/admin/logout', requireAuth, requireCsrf, asyncRoute(async (req, res) => {
  await audit({ userId: req.session.staff.id, event: 'staff_logout', req });
  req.session.destroy(() => res.json({ ok: true }));
}));

app.get('/api/admin/dashboard', requireAuth, asyncRoute(async (_req, res) => {
  const q = await pool.query(`select
    (select count(*)::int from participants) as participants,
    (select count(*)::int from samples) as samples,
    (select count(*)::int from lab_results where review_status='draft') as draft_results,
    (select count(*)::int from lab_results where review_status='published') as published_results`);
  res.json({ participants:q.rows[0].participants, samples:q.rows[0].samples, draftResults:q.rows[0].draft_results, publishedResults:q.rows[0].published_results });
}));

app.post('/api/admin/participants/search', requireAuth, requireCsrf, asyncRoute(async (req, res) => {
  const query = safeText(req.body?.query, 160);
  if (query.length < 3) return res.status(400).json({ message: 'กรุณาพิมพ์อย่างน้อย 3 ตัวอักษร' });
  let q, idHmac = null;
  if (/^\d{13}$/.test(query)) {
    if (!isValidThaiId(query)) return res.json({ participants: [] });
    idHmac = lookupHmac(query);
    q = await pool.query(`select participant_id,full_name,national_id_ciphertext,district,subdistrict,health_unit from participants where national_id_lookup_hmac=$1 limit 10`, [idHmac]);
  } else {
    q = await pool.query(`select participant_id,full_name,national_id_ciphertext,district,subdistrict,health_unit from participants where full_name ilike $1 order by created_at desc limit 20`, [`%${query}%`]);
  }
  await audit({ userId: req.session.staff.id, event: 'participant_search', idHmac, req, outcome: q.rowCount ? 'found' : 'not_found' });
  res.json({ participants: q.rows.map(p => ({ participantId:p.participant_id, fullName:p.full_name, maskedNationalId:maskId(decryptId(p.national_id_ciphertext)), area:`${p.subdistrict} / ${p.district}`, healthUnit:p.health_unit })) });
}));

app.post('/api/admin/samples/link', requireRole('admin','lab'), requireCsrf, asyncRoute(async (req, res) => {
  const participantId = safeText(req.body?.participantId, 60);
  const sampleCode = safeText(req.body?.sampleCode, 60).toUpperCase();
  const receivedAt = req.body?.receivedAt || null;
  if (!participantId || !/^[A-Z0-9-]{4,60}$/.test(sampleCode)) return res.status(400).json({ message: 'กรุณาตรวจสอบผู้เข้าร่วมและรหัสตัวอย่าง' });
  const p = await pool.query('select participant_id from participants where participant_id=$1', [participantId]);
  if (!p.rowCount) return res.status(404).json({ message: 'ไม่พบข้อมูลผู้เข้าร่วม' });
  const s = await pool.query(`insert into samples(sample_code,participant_id,received_at,created_by) values($1,$2,$3,$4) returning sample_id`, [sampleCode,participantId,receivedAt,req.session.staff.id]);
  await audit({ userId:req.session.staff.id,event:'sample_linked',participantId,sampleId:s.rows[0].sample_id,req });
  res.status(201).json({ linked:true });
}));

app.post('/api/admin/results', requireRole('admin','lab'), requireCsrf, asyncRoute(async (req, res) => {
  const sampleCode = safeText(req.body?.sampleCode,60).toUpperCase();
  const testDate = req.body?.testDate;
  const method = safeText(req.body?.method,120);
  const resultStatus = safeText(req.body?.resultStatus,30);
  const parasiteName = safeText(req.body?.parasiteName,500);
  const findings = safeText(req.body?.findings,1000);
  const recommendations = safeText(req.body?.recommendations,1500);
  if (!sampleCode || !/^\d{4}-\d{2}-\d{2}$/.test(String(testDate||'')) || !method || !['negative','positive','inconclusive','rejected'].includes(resultStatus)) {
    return res.status(400).json({ message: 'กรุณากรอกข้อมูลผลตรวจที่จำเป็นให้ครบถ้วน' });
  }
  const sample = await pool.query('select sample_id,participant_id from samples where sample_code=$1',[sampleCode]);
  if (!sample.rowCount) return res.status(404).json({ message: 'ไม่พบรหัสตัวอย่าง กรุณาตรวจสอบว่าจับคู่ตัวอย่างแล้ว' });
  const saved = await pool.query(
    `insert into lab_results(sample_id,test_date,method,result_status,parasite_name,findings,recommendations,entered_by,review_status)
     values($1,$2,$3,$4,$5,$6,$7,$8,'draft')
     on conflict(sample_id) do update set test_date=excluded.test_date,method=excluded.method,result_status=excluded.result_status,
       parasite_name=excluded.parasite_name,findings=excluded.findings,recommendations=excluded.recommendations,
       entered_by=excluded.entered_by,review_status='draft',reviewed_by=null,published_at=null,updated_at=now()
     where lab_results.review_status <> 'published' returning result_id`,
    [sample.rows[0].sample_id,testDate,method,resultStatus,parasiteName||null,findings||null,recommendations||null,req.session.staff.id]
  );
  if (!saved.rowCount) return res.status(409).json({ message: 'ผลตรวจนี้เผยแพร่แล้ว กรุณาให้ผู้ดูแลระบบดำเนินการแก้ไขอย่างเป็นทางการ' });
  await audit({ userId:req.session.staff.id,event:'lab_result_saved_draft',participantId:sample.rows[0].participant_id,sampleId:sample.rows[0].sample_id,resultId:saved.rows[0].result_id,req });
  res.status(201).json({ saved:true });
}));

app.get('/api/admin/review-queue', requireRole('admin','reviewer'), asyncRoute(async (_req, res) => {
  const q = await pool.query(`select lr.result_id,lr.test_date,lr.method,lr.result_status,lr.parasite_name,lr.findings,s.sample_code,p.full_name
    from lab_results lr join samples s on s.sample_id=lr.sample_id join participants p on p.participant_id=s.participant_id
    where lr.review_status='draft' order by lr.created_at asc limit 300`);
  const labels = { negative:'ไม่พบพยาธิ',positive:'พบพยาธิ',inconclusive:'แปลผลไม่ได้ / ตรวจซ้ำ',rejected:'ตัวอย่างไม่เหมาะสม' };
  res.json({ results:q.rows.map(r=>({resultId:r.result_id,sampleCode:r.sample_code,fullName:r.full_name,testDate:r.test_date,method:r.method,resultLabel:labels[r.result_status],parasiteName:r.parasite_name,findings:r.findings})) });
}));

app.post('/api/admin/results/:id/publish', requireRole('admin','reviewer'), requireCsrf, asyncRoute(async (req, res) => {
  const q = await pool.query(`update lab_results set review_status='published',published_at=now(),reviewed_by=$2,updated_at=now()
    where result_id=$1 and review_status='draft' returning result_id,sample_id`,[req.params.id,req.session.staff.id]);
  if (!q.rowCount) return res.status(404).json({ message: 'ไม่พบผลตรวจฉบับร่าง หรือผลตรวจถูกเผยแพร่แล้ว' });
  await audit({userId:req.session.staff.id,event:'lab_result_published',sampleId:q.rows[0].sample_id,resultId:q.rows[0].result_id,req});
  res.json({published:true});
}));

app.post('/api/admin/users', requireRole('admin'), requireCsrf, asyncRoute(async (req, res) => {
  const username = safeText(req.body?.username,80);
  const password = String(req.body?.password||'');
  const role = safeText(req.body?.role,20);
  if (!/^[a-zA-Z0-9._-]{4,80}$/.test(username) || password.length < 14 || !['admin','lab','reviewer'].includes(role)) {
    return res.status(400).json({message:'ชื่อผู้ใช้ต้องมี 4 ตัวขึ้นไป รหัสผ่านอย่างน้อย 14 ตัว และเลือกสิทธิ์ให้ถูกต้อง'});
  }
  const hash = await bcrypt.hash(password,12);
  try {
    const q = await pool.query('insert into staff_users(username,password_hash,role) values($1,$2,$3) returning staff_user_id',[username,hash,role]);
    await audit({userId:req.session.staff.id,event:'staff_user_created',req});
    res.status(201).json({created:true,id:q.rows[0].staff_user_id});
  } catch(err) {
    if(err.code==='23505') return res.status(409).json({message:'ชื่อผู้ใช้นี้มีอยู่แล้ว'});
    throw err;
  }
}));

app.use('/api', (_req,res)=>res.status(404).json({message:'ไม่พบ API ที่เรียกใช้งาน'}));
app.use(express.static(path.join(__dirname,'..','public'),{extensions:['html'],dotfiles:'deny',maxAge:isProd?'1h':0}));
app.get('*',(_req,res)=>res.sendFile(path.join(__dirname,'..','public','index.html')));
app.use((err,_req,res,_next)=>{console.error('Request error:',err.message);if(res.headersSent)return;res.status(500).json({message:'ระบบขัดข้องชั่วคราว กรุณาลองใหม่ภายหลัง'});});

async function start(){
  const sql=fs.readFileSync(path.join(__dirname,'migrations','001_init.sql'),'utf8');
  await pool.query(sql);
  const username=safeText(process.env.ADMIN_USERNAME,80), password=process.env.ADMIN_PASSWORD||'';
  if(username&&password){
    if(password.length<14)throw new Error('ADMIN_PASSWORD must be at least 14 characters');
    const exists=await pool.query('select staff_user_id from staff_users where username=$1',[username]);
    if(!exists.rowCount){
      const hash=await bcrypt.hash(password,12);
      await pool.query('insert into staff_users(username,password_hash,role) values($1,$2,$3)',[username,hash,'admin']);
      console.log(`Initial admin account created: ${username}`);
    }
  }else console.warn('No initial admin created: set ADMIN_USERNAME and ADMIN_PASSWORD.');
  app.listen(PORT,()=>console.log(`Portal listening on ${PORT}`));
}
start().catch(err=>{console.error('Startup failed:',err);process.exit(1);});
