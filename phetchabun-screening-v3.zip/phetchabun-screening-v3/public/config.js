window.APP_CONFIG = { apiBaseUrl: "", privacyNoticeUrl: "" };
